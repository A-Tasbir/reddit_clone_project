package com.example.pocketledger

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

/** Versioned, checksummed, user-owned JSON backup. Restore is atomic at the database layer. */
object BackupManager {
    const val BACKUP_VERSION = 1
    private const val FORMAT = "pocketledger-backup"
    private const val PRE_RESTORE = "pre_restore_backup.json"
    const val MAX_IMPORT_BYTES = 50 * 1024 * 1024

    data class Snapshot(val accounts: List<Account>, val movements: List<Movement>, val exportedAt: Long)

    fun encode(accounts: List<Account>, movements: List<Movement>): ByteArray {
        val a = JSONArray()
        accounts.forEach { it ->
            a.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("kind", it.kind.name)
                put("openingBalance", it.openingBalance)
                put("createdAt", it.createdAt); put("updatedAt", it.updatedAt)
                put("deletedAt", it.deletedAt ?: JSONObject.NULL)
            })
        }
        val m = JSONArray()
        movements.forEach { it ->
            m.put(JSONObject().apply {
                put("id", it.id); put("type", it.type.name)
                put("fromAccount", it.fromAccount ?: JSONObject.NULL)
                put("toAccount", it.toAccount ?: JSONObject.NULL)
                put("category", it.category); put("amount", it.amount); put("note", it.note)
                put("occurredAt", it.occurredAt)
                put("createdAt", it.createdAt); put("updatedAt", it.updatedAt)
                put("deletedAt", it.deletedAt ?: JSONObject.NULL)
            })
        }
        val content = JSONObject().put("accounts", a).put("movements", m).toString()
        val output = JSONObject()
            .put("format", FORMAT)
            .put("backupVersion", BACKUP_VERSION)
            .put("exportedAt", System.currentTimeMillis())
            .put("checksumSha256", sha256(content))
            .put("data", content)
        return output.toString(2).toByteArray(StandardCharsets.UTF_8)
    }

    fun decode(bytes: ByteArray): Snapshot {
        require(bytes.size <= MAX_IMPORT_BYTES) { "Backup file is too large" }
        val root = JSONObject(String(bytes, StandardCharsets.UTF_8))
        require(root.getString("format") == FORMAT) { "Not a PocketLedger backup" }
        require(root.getInt("backupVersion") == BACKUP_VERSION) {
            "Unsupported backup version. Update PocketLedger before restoring this file."
        }
        val content = root.getString("data")
        val expected = root.getString("checksumSha256")
        require(MessageDigest.isEqual(
            expected.toByteArray(StandardCharsets.UTF_8),
            sha256(content).toByteArray(StandardCharsets.UTF_8)
        )) { "Backup checksum mismatch: the file may be incomplete or altered" }
        val payload = JSONObject(content)
        val accountsJson = payload.getJSONArray("accounts")
        val movementsJson = payload.getJSONArray("movements")
        require(accountsJson.length() <= 5000 && movementsJson.length() <= 250000) { "Backup contains too many records" }
        val accounts = (0 until accountsJson.length()).map { i ->
            accountsJson.getJSONObject(i).let { o ->
                val id = o.getString("id")
                UUID.fromString(id)
                Account(
                    id, o.getString("name"), AccountKind.valueOf(o.getString("kind")),
                    o.getLong("openingBalance"), o.getLong("createdAt"), o.getLong("updatedAt"),
                    o.longOrNull("deletedAt")
                )
            }
        }
        val movements = (0 until movementsJson.length()).map { i ->
            movementsJson.getJSONObject(i).let { o ->
                val id = o.getString("id")
                UUID.fromString(id)
                Movement(
                    id, MovementType.valueOf(o.getString("type")), o.stringOrNull("fromAccount"),
                    o.stringOrNull("toAccount"), o.getString("category"), o.getLong("amount"),
                    o.getString("note"), o.getLong("occurredAt"), o.getLong("createdAt"),
                    o.getLong("updatedAt"), o.longOrNull("deletedAt")
                )
            }
        }
        return Snapshot(accounts, movements, root.getLong("exportedAt"))
    }

    fun saveBeforeRestore(context: Context, database: LedgerDatabase) {
        context.openFileOutput(PRE_RESTORE, Context.MODE_PRIVATE).use { out ->
            out.write(encode(database.accounts(), database.movements(includeDeleted = true)))
            out.fd.sync()
        }
    }

    fun hasPreRestore(context: Context): Boolean = context.getFileStreamPath(PRE_RESTORE).exists()

    fun loadPreRestore(context: Context): Snapshot = context.openFileInput(PRE_RESTORE).use { stream ->
        val bytes = stream.readBytes()
        require(bytes.size <= MAX_IMPORT_BYTES) { "Internal backup is too large" }
        decode(bytes)
    }

    private fun JSONObject.stringOrNull(name: String): String? = if (isNull(name)) null else getString(name)
    private fun JSONObject.longOrNull(name: String): Long? = if (isNull(name)) null else getLong(name)
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray(StandardCharsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
