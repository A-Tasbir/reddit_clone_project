package com.example.pocketledger

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AccountKind { ASSET, CREDIT }
enum class MovementType { EXPENSE, INCOME, TRANSFER }

data class Account(
    val id: String,
    val name: String,
    val kind: AccountKind,
    val openingBalance: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

data class Movement(
    val id: String,
    val type: MovementType,
    val fromAccount: String?,
    val toAccount: String?,
    val category: String,
    val amount: Long,
    val note: String,
    val occurredAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

val expenseCategories = listOf("Food", "Groceries", "Rent", "Transport", "Utilities", "Shopping", "Health", "Education", "Entertainment", "Other")
val incomeCategories = listOf("Salary", "Part-time work", "Gift", "Refund", "Other")

fun yen(value: Long): String = "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(value)
fun dateText(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date(timestamp))
fun monthBounds(now: Long = System.currentTimeMillis()): Pair<Long, Long> {
    val cal = java.util.Calendar.getInstance().apply {
        timeInMillis = now
        set(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }
    val start = cal.timeInMillis
    cal.add(java.util.Calendar.MONTH, 1)
    return start to cal.timeInMillis
}

fun accountBalances(accounts: List<Account>, movements: List<Movement>): Map<String, Long> {
    val result = accounts.associate { it.id to it.openingBalance }.toMutableMap()
    for (m in movements) {
        if (m.deletedAt != null) continue
        if (m.type != MovementType.INCOME) {
            val from = m.fromAccount ?: continue
            result[from] = (result[from] ?: 0L) - m.amount
        }
        if (m.type != MovementType.EXPENSE) {
            val to = m.toAccount ?: continue
            result[to] = (result[to] ?: 0L) + m.amount
        }
    }
    return result
}
