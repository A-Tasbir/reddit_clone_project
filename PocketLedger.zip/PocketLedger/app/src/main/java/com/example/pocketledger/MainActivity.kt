package com.example.pocketledger

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

private val background = Color(0xFF0A111C)
private val panel = Color(0xFF152133)
private val panelSecondary = Color(0xFF1C2B40)
private val accent = Color(0xFF5AE4C5)
private val warning = Color(0xFFFFC481)
private val errorPink = Color(0xFFFF8799)
private val lightText = Color(0xFFECF3F9)
private val muted = Color(0xFF9BB1C4)

private val ledgerColorScheme = darkColorScheme(
    primary = accent, onPrimary = background,
    background = background, onBackground = lightText,
    surface = panel, onSurface = lightText,
    surfaceVariant = panelSecondary, onSurfaceVariant = muted,
    outline = Color(0xFF526477), error = errorPink
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = ledgerColorScheme) {
                PocketLedgerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PocketLedgerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val database = remember { LedgerDatabase(context.applicationContext) }
    var revision by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(0) }
    var editAccount by remember { mutableStateOf<Account?>(null) }
    var showAccountEditor by remember { mutableStateOf(false) }
    var editMovement by remember { mutableStateOf<Movement?>(null) }
    var showMovementEditor by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<BackupManager.Snapshot?>(null) }
    var restoreInternal by remember { mutableStateOf(false) }

    val accounts = remember(revision) { database.accounts() }
    val movements = remember(revision) { database.movements() }
    val balances = remember(accounts, movements) { accountBalances(accounts, movements) }

    fun notify(message: String) { Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
    fun refresh() { revision++ }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                val bytes = BackupManager.encode(database.accounts(), database.movements(includeDeleted = true))
                requireNotNull(context.contentResolver.openOutputStream(uri, "wt")) { "Cannot write this location" }.use { it.write(bytes) }
                notify("Backup exported successfully")
            } catch (e: Exception) { notify("Export failed: ${e.message}") }
        }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val bytes = requireNotNull(context.contentResolver.openInputStream(uri)) { "Cannot read file" }.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    var length = 0
                    while (true) {
                        val count = input.read(chunk)
                        if (count == -1) break
                        length += count
                        require(length <= BackupManager.MAX_IMPORT_BYTES) { "Backup exceeds size limit" }
                        output.write(chunk, 0, count)
                    }
                    output.toByteArray()
                }
                pendingRestore = BackupManager.decode(bytes)
                restoreInternal = false
            } catch (e: Exception) { notify("Cannot open backup: ${e.message}") }
        }
    }

    Scaffold(
        containerColor = background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("PocketLedger", fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp)
                        Text("Your money, in your hands", fontSize = 11.sp, color = muted)
                    }
                },
                actions = {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = accent,
                        modifier = Modifier.padding(end = 16.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = background)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = panel) {
                val tabs = listOf(
                    Triple("Home", Icons.Default.Home, 0),
                    Triple("Activity", Icons.Default.ReceiptLong, 1),
                    Triple("Accounts", Icons.Default.AccountBalanceWallet, 2),
                    Triple("Backup", Icons.Default.SaveAlt, 3)
                )
                tabs.forEach { (name, icon, index) ->
                    NavigationBarItem(
                        selected = page == index, onClick = { page = index },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = background, indicatorColor = accent,
                            unselectedIconColor = muted, unselectedTextColor = muted
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (page == 0 || page == 1) {
                ExtendedFloatingActionButton(
                    text = { Text("New entry") }, icon = { Icon(Icons.Default.Add, null) },
                    onClick = { editMovement = null; showMovementEditor = true },
                    containerColor = accent, contentColor = background
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (page) {
                0 -> HomePage(accounts, movements, balances, onAccount = {
                    editAccount = it; showAccountEditor = true
                }, onAdd = { editMovement = null; showMovementEditor = true })
                1 -> ActivityPage(movements, accounts, onEdit = {
                    editMovement = it; showMovementEditor = true
                }, onDelete = { database.deleteMovement(it.id); refresh(); notify("Entry deleted") })
                2 -> AccountsPage(accounts, balances, onAdd = {
                    editAccount = null; showAccountEditor = true
                }, onEdit = { editAccount = it; showAccountEditor = true })
                3 -> BackupPage(
                    accounts.size, movements.size,
                    hasUndo = BackupManager.hasPreRestore(context),
                    onExport = {
                        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        export.launch("PocketLedger-$date.json")
                    },
                    onImport = { import.launch(arrayOf("*/*")) },
                    onUndo = {
                        try {
                            pendingRestore = BackupManager.loadPreRestore(context)
                            restoreInternal = true
                        } catch (e: Exception) { notify("Restore point unavailable: ${e.message}") }
                    }
                )
            }
        }
    }

    if (showAccountEditor) {
        AccountEditor(
            original = editAccount,
            onDismiss = { showAccountEditor = false },
            onSave = {
                try {
                    database.saveAccount(it); refresh(); showAccountEditor = false
                    notify("Account saved")
                } catch (e: Exception) { notify("Could not save account: ${e.message}") }
            },
            onDelete = { account ->
                if (database.removeEmptyAccount(account.id)) {
                    refresh(); showAccountEditor = false; notify("Unused account removed")
                } else notify("Cannot remove an account with transaction history")
            }
        )
    }

    if (showMovementEditor) {
        MovementEditor(
            original = editMovement,
            accounts = accounts.filter { it.deletedAt == null },
            onDismiss = { showMovementEditor = false },
            onSave = {
                try {
                    database.saveMovement(it); refresh(); showMovementEditor = false
                    notify("Entry saved")
                } catch (e: Exception) { notify("Could not save: ${e.message}") }
            }
        )
    }

    pendingRestore?.let { snapshot ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text(if (restoreInternal) "Recover previous data?" else "Replace all current data?") },
            text = {
                Text("This backup has ${snapshot.accounts.size} accounts and ${snapshot.movements.size} entries. " +
                    "Your current data will be replaced. ${if (!restoreInternal) "An internal restore point is saved first; still export a separate file for safety." else "Export a separate backup first if you want to retain recent changes."}")
            },
            confirmButton = {
                Button(onClick = {
                    try {
                        // Do not overwrite the existing recovery point while undoing a restore.
                        if (!restoreInternal) BackupManager.saveBeforeRestore(context, database)
                        database.restore(snapshot.accounts, snapshot.movements)
                        refresh(); pendingRestore = null; notify("Backup restored")
                    } catch (e: Exception) { pendingRestore = null; notify("Restore failed: ${e.message}") }
                }) { Text("Replace and restore") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PageHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = muted, fontSize = 13.sp)
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun HomePage(
    accounts: List<Account>, movements: List<Movement>, balances: Map<String, Long>,
    onAccount: (Account) -> Unit, onAdd: () -> Unit
) {
    val assets = accounts.filter { it.kind == AccountKind.ASSET }.sumOf { balances[it.id] ?: 0L }
    val debts = accounts.filter { it.kind == AccountKind.CREDIT }.sumOf { max(0L, -(balances[it.id] ?: 0L)) }
    val net = accounts.sumOf { balances[it.id] ?: 0L }
    val (start, end) = monthBounds()
    val monthly = movements.filter { it.occurredAt in start until end }
    val expenses = monthly.filter { it.type == MovementType.EXPENSE }
    val income = monthly.filter { it.type == MovementType.INCOME }.sumOf { it.amount }
    val spent = expenses.sumOf { it.amount }
    val spending = expenses.groupBy { it.category }.mapValues { (_, entries) -> entries.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(4.dp))
        PageHeading("Overview", "A clear picture of all your accounts")
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183A45)), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("TOTAL AVAILABLE", color = muted, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(yen(assets), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = lightText)
                HorizontalDivider(color = Color.White.copy(alpha = .12f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Credit card owed", color = muted, fontSize = 12.sp); Text(yen(debts), color = warning, fontWeight = FontWeight.SemiBold) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Net position", color = muted, fontSize = 12.sp)
                        Text(yen(net), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Income · month", yen(income), accent, Modifier.weight(1f))
            MetricCard("Spent · month", yen(spent), warning, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionHeader("Your accounts")
            Text("Tap to edit", color = muted, fontSize = 12.sp)
        }
        accounts.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { account ->
                    AccountTile(account, balances[account.id] ?: 0L, Modifier.weight(1f)) { onAccount(account) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        SectionHeader("Spending this month")
        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (spending.isEmpty()) {
                    Text("No expenses yet. Record your first expense to see a breakdown.", color = muted)
                } else {
                    val maximum = max(1L, spending.first().second)
                    spending.take(6).forEach { (category, amount) ->
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category, fontSize = 13.sp); Text(yen(amount), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                            LinearProgressIndicator(
                                progress = { amount.toFloat() / maximum }, modifier = Modifier.fillMaxWidth().height(7.dp),
                                color = accent, trackColor = panelSecondary
                            )
                        }
                    }
                }
            }
        }
        if (movements.isEmpty()) {
            OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("Add your first transaction") }
        }
        Spacer(Modifier.height(84.dp))
    }
}

@Composable
private fun MetricCard(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = muted, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = valueColor)
        }
    }
}

@Composable
private fun AccountTile(account: Account, balance: Long, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = panel)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(if (account.kind == AccountKind.CREDIT) Icons.Default.CreditCard else Icons.Default.AccountBalanceWallet,
                contentDescription = null, tint = if (account.kind == AccountKind.CREDIT) warning else accent)
            Text(account.name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = muted, fontSize = 13.sp)
            Text(yen(if (account.kind == AccountKind.CREDIT) max(0L, -balance) else balance),
                fontSize = 19.sp, fontWeight = FontWeight.Bold,
                color = if (account.kind == AccountKind.CREDIT) warning else lightText)
            Text(if (account.kind == AccountKind.CREDIT) "Amount owed" else "Available", color = muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ActivityPage(movements: List<Movement>, accounts: List<Account>, onEdit: (Movement) -> Unit, onDelete: (Movement) -> Unit) {
    var search by remember { mutableStateOf("") }
    var awaitingDelete by remember { mutableStateOf<Movement?>(null) }
    val names = accounts.associate { it.id to it.name }
    val visible = movements.filter { m ->
        search.isBlank() || listOf(m.note, m.category, names[m.fromAccount].orEmpty(), names[m.toAccount].orEmpty())
            .any { it.contains(search, ignoreCase = true) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(4.dp))
        PageHeading("Activity", "Every yen, easy to find")
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search entries or accounts") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp))
        if (visible.isEmpty()) {
            Text("No entries found.", color = muted, modifier = Modifier.padding(top = 24.dp))
        } else {
            androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(visible.size) { index ->
                    val m = visible[index]
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (m.type == MovementType.TRANSFER) "Transfer" else m.category,
                                    fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text(when (m.type) {
                                    MovementType.EXPENSE -> "From ${names[m.fromAccount].orEmpty()}"
                                    MovementType.INCOME -> "Into ${names[m.toAccount].orEmpty()}"
                                    MovementType.TRANSFER -> "${names[m.fromAccount].orEmpty()} → ${names[m.toAccount].orEmpty()}"
                                }, color = muted, fontSize = 12.sp)
                                if (m.note.isNotBlank()) Text(m.note, fontSize = 12.sp, maxLines = 2)
                                Text(dateText(m.occurredAt), fontSize = 11.sp, color = muted)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text((if (m.type == MovementType.EXPENSE) "−" else if (m.type == MovementType.INCOME) "+" else "") + yen(m.amount),
                                    color = when (m.type) { MovementType.EXPENSE -> warning; MovementType.INCOME -> accent; MovementType.TRANSFER -> lightText },
                                    fontWeight = FontWeight.Bold)
                                Row {
                                    IconButton(onClick = { onEdit(m) }) { Icon(Icons.Default.Edit, "Edit entry", tint = muted, modifier = Modifier.size(18.dp)) }
                                    IconButton(onClick = { awaitingDelete = m }) { Icon(Icons.Default.DeleteOutline, "Delete entry", tint = muted, modifier = Modifier.size(18.dp)) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    awaitingDelete?.let { movement ->
        AlertDialog(
            onDismissRequest = { awaitingDelete = null }, title = { Text("Delete transaction?") },
            text = { Text("This removes the entry from your balances and reports. You cannot undo it from the screen.") },
            confirmButton = { TextButton(onClick = { onDelete(movement); awaitingDelete = null }) { Text("Delete", color = errorPink) } },
            dismissButton = { TextButton(onClick = { awaitingDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AccountsPage(accounts: List<Account>, balances: Map<String, Long>, onAdd: () -> Unit, onEdit: (Account) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(4.dp))
        PageHeading("Accounts", "Keep cash, wallets, banks and cards separate")
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Create account") }
        accounts.forEach { a ->
            Card(modifier = Modifier.fillMaxWidth().clickable { onEdit(a) },
                colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (a.kind == AccountKind.CREDIT) Icons.Default.CreditCard else Icons.Default.Wallet,
                        contentDescription = null, tint = if (a.kind == AccountKind.CREDIT) warning else accent)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.SemiBold)
                        Text(if (a.kind == AccountKind.CREDIT) "Credit / amount owed" else "Cash or stored value", color = muted, fontSize = 12.sp)
                    }
                    Text(yen(if (a.kind == AccountKind.CREDIT) max(0L, -(balances[a.id] ?: 0L)) else (balances[a.id] ?: 0L)),
                        fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, null, tint = muted)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panelSecondary)) {
            Text("Tip: A credit card is a debt account, not extra available cash. Move money from Bank to Credit Card using Transfer when paying your card bill.",
                color = muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun BackupPage(totalAccounts: Int, totalEntries: Int, hasUndo: Boolean, onExport: () -> Unit, onImport: () -> Unit, onUndo: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(4.dp))
        PageHeading("Backup & privacy", "Your data stays on this device")
        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudOff, null, tint = accent)
                    Spacer(Modifier.width(10.dp))
                    Text("Offline-first", fontWeight = FontWeight.Bold)
                }
                Text("No login, internet connection, or cloud account is needed. Data is saved to the app's local database.", color = muted)
                Text("$totalAccounts accounts · $totalEntries active transactions", color = accent, fontSize = 13.sp)
            }
        }
        SectionHeader("Keep your data safe")
        Button(onClick = onExport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(10.dp)); Text("Export backup file")
        }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(10.dp)); Text("Restore from backup file")
        }
        if (hasUndo) {
            OutlinedButton(onClick = onUndo, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.History, null); Spacer(Modifier.width(10.dp)); Text("Recover data from before last restore")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("How backups work", fontWeight = FontWeight.SemiBold)
                Text("A portable JSON file includes accounts, starting balances, categories, transaction history and record IDs. It uses a version marker and SHA-256 checksum to detect damaged files.", color = muted, fontSize = 13.sp)
                HorizontalDivider(color = panelSecondary)
                Text("Backups are NOT encrypted. Store them privately. Save a copy outside this phone before reinstalling or uninstalling the app; uninstalling deletes its local database and internal recovery point.",
                    color = warning, fontSize = 13.sp)
            }
        }
        SectionHeader("Future cloud sync")
        Text("The account and transaction records use stable UUIDs and modification timestamps. Cloud sync can be introduced later without changing the core ledger. Cloud is not connected in this version.", color = muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AccountEditor(original: Account?, onDismiss: () -> Unit, onSave: (Account) -> Unit, onDelete: (Account) -> Unit) {
    var name by remember(original) { mutableStateOf(original?.name.orEmpty()) }
    var kind by remember(original) { mutableStateOf(original?.kind ?: AccountKind.ASSET) }
    var opening by remember(original) { mutableStateOf(original?.openingBalance?.let { abs(it).toString() }.orEmpty()) }
    val numeric = opening.toLongOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (original == null) "New account" else "Edit account") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("Account name") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == AccountKind.ASSET, onClick = { kind = AccountKind.ASSET }, label = { Text("Cash / bank") })
                    FilterChip(selected = kind == AccountKind.CREDIT, onClick = { kind = AccountKind.CREDIT }, label = { Text("Credit card") })
                }
                OutlinedTextField(opening, { opening = it.filter(Char::isDigit).take(13) },
                    label = { Text(if (kind == AccountKind.CREDIT) "Starting amount owed (¥)" else "Starting balance (¥)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("This is the starting amount, before transactions. Changing it affects your calculated current balance.", color = muted, fontSize = 12.sp)
                if (original != null) TextButton(onClick = { onDelete(original) }) { Text("Remove unused account", color = errorPink) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && numeric != null && numeric in 0..1_000_000_000_000L,
                onClick = {
                    val now = System.currentTimeMillis()
                    onSave(Account(original?.id ?: UUID.randomUUID().toString(), name.trim(), kind,
                        (numeric ?: 0L) * if (kind == AccountKind.CREDIT) -1 else 1,
                        original?.createdAt ?: now, now, original?.deletedAt))
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun MovementEditor(original: Movement?, accounts: List<Account>, onDismiss: () -> Unit, onSave: (Movement) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var type by remember(original) { mutableStateOf(original?.type ?: MovementType.EXPENSE) }
    var from by remember(original, accounts) { mutableStateOf(original?.fromAccount ?: accounts.firstOrNull()?.id) }
    var to by remember(original, accounts) { mutableStateOf(original?.toAccount ?: accounts.firstOrNull { it.id != from }?.id ?: accounts.firstOrNull()?.id) }
    var amount by remember(original) { mutableStateOf(original?.amount?.toString().orEmpty()) }
    var note by remember(original) { mutableStateOf(original?.note.orEmpty()) }
    var category by remember(original) { mutableStateOf(original?.category ?: expenseCategories.first()) }
    var date by remember(original) { mutableLongStateOf(original?.occurredAt ?: System.currentTimeMillis()) }
    val choices = if (type == MovementType.INCOME) incomeCategories else expenseCategories
    val validAmount = amount.toLongOrNull()?.let { it in 1..1_000_000_000_000L } == true
    val validAccounts = when (type) {
        MovementType.EXPENSE -> from != null
        MovementType.INCOME -> to != null
        MovementType.TRANSFER -> from != null && to != null && from != to
    }
    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = panel),
            modifier = Modifier.fillMaxWidth().fillMaxHeight(.90f)) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text(if (original == null) "Add entry" else "Edit entry", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        MovementType.entries.forEach { item ->
                            FilterChip(selected = type == item, onClick = {
                                type = item
                                if (item != MovementType.TRANSFER) category = if (item == MovementType.INCOME) incomeCategories.first() else expenseCategories.first()
                            }, label = { Text(item.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 12.sp) })
                        }
                    }
                    OutlinedTextField(amount, { amount = it.filter(Char::isDigit).take(13) },
                        label = { Text("Amount (¥)") }, prefix = { Text("¥") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true,
                        modifier = Modifier.fillMaxWidth())
                    if (type != MovementType.INCOME) {
                        Picker("From account", accounts.map { it.id }, from, { from = it }) { id -> accounts.firstOrNull { it.id == id }?.name ?: "Unknown account" }
                    }
                    if (type != MovementType.EXPENSE) {
                        Picker("To account", accounts.map { it.id }, to, { to = it }) { id -> accounts.firstOrNull { it.id == id }?.name ?: "Unknown account" }
                    }
                    if (type != MovementType.TRANSFER) {
                        Picker("Category", choices, category, { category = it }) { it }
                    } else {
                        Text("Transfers do not count as income or expenses.", color = muted, fontSize = 12.sp)
                    }
                    OutlinedTextField(note, { note = it.take(300) }, label = { Text("Note (optional)") },
                        modifier = Modifier.fillMaxWidth(), maxLines = 3)
                    OutlinedButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = date }
                        DatePickerDialog(context, { _, y, m, d ->
                            cal.set(Calendar.YEAR, y); cal.set(Calendar.MONTH, m); cal.set(Calendar.DAY_OF_MONTH, d)
                            date = cal.timeInMillis
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text(dateText(date))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(enabled = validAmount && validAccounts, onClick = {
                        val now = System.currentTimeMillis()
                        onSave(Movement(
                            original?.id ?: UUID.randomUUID().toString(), type,
                            if (type == MovementType.INCOME) null else from,
                            if (type == MovementType.EXPENSE) null else to,
                            if (type == MovementType.TRANSFER) "Transfer" else category,
                            amount.toLong(), note.trim(), date,
                            original?.createdAt ?: now, now, original?.deletedAt
                        ))
                    }) { Text("Save entry") }
                }
            }
        }
    }
}

@Composable
private fun <T> Picker(label: String, items: List<T>, selection: T?, onSelect: (T) -> Unit, text: (T) -> String) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = muted, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selection?.let(text) ?: "Select", modifier = Modifier.weight(1f), maxLines = 1)
                Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                items.forEach { item ->
                    DropdownMenuItem(text = { Text(text(item)) }, onClick = { onSelect(item); expanded = false })
                }
            }
        }
    }
}
