package com.example.pocketledger

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

/** Offline source of truth. No destructive upgrade migrations. */
class LedgerDatabase(context: Context) : SQLiteOpenHelper(context, "pocket_ledger.db", null, DATABASE_VERSION) {
    companion object { const val DATABASE_VERSION = 1 }

    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE accounts (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL,
                opening_balance INTEGER NOT NULL, created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL, deleted_at INTEGER
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE movements (
                id TEXT PRIMARY KEY, kind TEXT NOT NULL,
                from_account_id TEXT REFERENCES accounts(id),
                to_account_id TEXT REFERENCES accounts(id),
                category TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0),
                note TEXT NOT NULL, occurred_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
                deleted_at INTEGER
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX movements_by_date ON movements (occurred_at DESC)")
        val now = System.currentTimeMillis()
        for ((name, kind) in listOf(
            "Cash" to AccountKind.ASSET,
            "PayPay" to AccountKind.ASSET,
            "Bank" to AccountKind.ASSET,
            "Credit Card" to AccountKind.CREDIT
        )) {
            val account = Account(UUID.randomUUID().toString(), name, kind, 0L, now, now)
            db.insertOrThrow("accounts", null, accountValues(account))
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Future versions must migrate in place. Never DROP TABLE in an upgrade.
        // Version 1 is the initial schema.
        if (oldVersion != newVersion) {
            throw IllegalStateException("Missing database migration from $oldVersion to $newVersion")
        }
    }

    fun accounts(): List<Account> {
        val list = mutableListOf<Account>()
        readableDatabase.query("accounts", null, null, null, null, null, "created_at, name").use { c ->
            while (c.moveToNext()) list.add(readAccount(c))
        }
        return list
    }

    fun movements(includeDeleted: Boolean = false): List<Movement> {
        val list = mutableListOf<Movement>()
        readableDatabase.query(
            "movements", null, if (includeDeleted) null else "deleted_at IS NULL",
            null, null, null, "occurred_at DESC, created_at DESC"
        ).use { c -> while (c.moveToNext()) list.add(readMovement(c)) }
        return list
    }

    fun saveAccount(account: Account) {
        require(account.name.isNotBlank() && account.name.length <= 60)
        val db = writableDatabase
        val previousKind = db.query("accounts", arrayOf("kind"), "id = ?", arrayOf(account.id), null, null, null).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
        if (previousKind != null && previousKind != account.kind.name) {
            val used = db.rawQuery(
                "SELECT COUNT(*) FROM movements WHERE from_account_id = ? OR to_account_id = ?", arrayOf(account.id, account.id)
            ).use { c -> c.moveToFirst(); c.getLong(0) > 0L }
            require(!used) { "Account type cannot change after transactions have been recorded" }
        }
        val values = accountValues(account)
        val updated = db.update("accounts", values, "id = ?", arrayOf(account.id))
        if (updated == 0) db.insertOrThrow("accounts", null, values)
    }

    fun removeEmptyAccount(id: String): Boolean {
        val db = writableDatabase
        val used = db.rawQuery(
            "SELECT COUNT(*) FROM movements WHERE from_account_id = ? OR to_account_id = ?", arrayOf(id, id)
        ).use { c -> c.moveToFirst(); c.getLong(0) > 0L }
        if (used) return false
        db.delete("accounts", "id = ?", arrayOf(id))
        return true
    }

    fun saveMovement(movement: Movement) {
        validateMovement(movement)
        writableDatabase.insertWithOnConflict(
            "movements", null, movementValues(movement), SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun deleteMovement(id: String) {
        writableDatabase.update("movements", ContentValues().apply {
            put("deleted_at", System.currentTimeMillis())
            put("updated_at", System.currentTimeMillis())
        }, "id = ?", arrayOf(id))
    }

    /** Validated payload is committed as a single transaction: no partially restored database. */
    fun restore(accounts: List<Account>, movements: List<Movement>) {
        require(accounts.isNotEmpty() || movements.isEmpty()) { "Entries need at least one account" }
        require(accounts.map { it.id }.toSet().size == accounts.size) { "Duplicate account IDs" }
        require(movements.map { it.id }.toSet().size == movements.size) { "Duplicate transaction IDs" }
        val ids = accounts.map { it.id }.toSet()
        for (a in accounts) require(a.id.isNotBlank() && a.name.isNotBlank())
        for (m in movements) {
            validateMovement(m)
            require(m.fromAccount == null || m.fromAccount in ids) { "Missing source account" }
            require(m.toAccount == null || m.toAccount in ids) { "Missing destination account" }
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("movements", null, null)
            db.delete("accounts", null, null)
            accounts.forEach { db.insertOrThrow("accounts", null, accountValues(it)) }
            movements.forEach { db.insertOrThrow("movements", null, movementValues(it)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun validateMovement(m: Movement) {
        require(m.amount > 0 && m.amount <= 1_000_000_000_000L) { "Amount must be positive and reasonable" }
        require(m.category.length <= 80 && m.note.length <= 300)
        when (m.type) {
            MovementType.EXPENSE -> require(m.fromAccount != null && m.toAccount == null)
            MovementType.INCOME -> require(m.toAccount != null && m.fromAccount == null)
            MovementType.TRANSFER -> require(m.fromAccount != null && m.toAccount != null && m.fromAccount != m.toAccount)
        }
    }

    private fun accountValues(a: Account) = ContentValues().apply {
        put("id", a.id); put("name", a.name); put("kind", a.kind.name)
        put("opening_balance", a.openingBalance); put("created_at", a.createdAt)
        put("updated_at", a.updatedAt)
        if (a.deletedAt == null) putNull("deleted_at") else put("deleted_at", a.deletedAt)
    }

    private fun movementValues(m: Movement) = ContentValues().apply {
        put("id", m.id); put("kind", m.type.name)
        if (m.fromAccount == null) putNull("from_account_id") else put("from_account_id", m.fromAccount)
        if (m.toAccount == null) putNull("to_account_id") else put("to_account_id", m.toAccount)
        put("category", m.category); put("amount", m.amount); put("note", m.note)
        put("occurred_at", m.occurredAt); put("created_at", m.createdAt)
        put("updated_at", m.updatedAt)
        if (m.deletedAt == null) putNull("deleted_at") else put("deleted_at", m.deletedAt)
    }

    private fun Cursor.text(key: String): String = getString(getColumnIndexOrThrow(key))
    private fun Cursor.number(key: String): Long = getLong(getColumnIndexOrThrow(key))
    private fun Cursor.optional(key: String): String? = getColumnIndexOrThrow(key).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.optionalLong(key: String): Long? = getColumnIndexOrThrow(key).let { if (isNull(it)) null else getLong(it) }

    private fun readAccount(c: Cursor): Account = Account(
        c.text("id"), c.text("name"), AccountKind.valueOf(c.text("kind")),
        c.number("opening_balance"), c.number("created_at"), c.number("updated_at"), c.optionalLong("deleted_at")
    )

    private fun readMovement(c: Cursor): Movement = Movement(
        c.text("id"), MovementType.valueOf(c.text("kind")), c.optional("from_account_id"),
        c.optional("to_account_id"), c.text("category"), c.number("amount"),
        c.text("note"), c.number("occurred_at"), c.number("created_at"),
        c.number("updated_at"), c.optionalLong("deleted_at")
    )
}
