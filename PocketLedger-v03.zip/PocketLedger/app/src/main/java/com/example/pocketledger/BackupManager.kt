package com.example.pocketledger

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

/** V2 adds custom categories, shared expenses and repayments. V1 files remain readable. */
object BackupManager {
    const val BACKUP_VERSION = 2
    private const val FORMAT = "pocketledger-backup"
    private const val PRE_RESTORE = "pre_restore_backup.json"
    const val MAX_IMPORT_BYTES = 50 * 1024 * 1024

    data class Snapshot(
        val accounts: List<Account>,
        val movements: List<Movement>,
        val categories: List<LedgerCategory>,
        val shares: List<SharedExpense>,
        val repayments: List<Repayment>,
        val exportedAt: Long
    )

    fun capture(db: LedgerDatabase) = Snapshot(db.accounts(), db.movements(includeDeleted = true), db.categories(), db.shares(), db.repayments(includeDeleted = true), System.currentTimeMillis())

    fun encode(snapshot: Snapshot): ByteArray {
        val accounts = JSONArray().apply { snapshot.accounts.forEach { a -> put(JSONObject().apply {
            put("id", a.id); put("name", a.name); put("kind", a.kind.name)
            put("openingBalance", a.openingBalance); put("createdAt", a.createdAt); put("updatedAt", a.updatedAt)
            put("deletedAt", a.deletedAt ?: JSONObject.NULL)
        }) } }
        val movements = JSONArray().apply { snapshot.movements.forEach { m -> put(JSONObject().apply {
            put("id", m.id); put("type", m.type.name)
            put("fromAccount", m.fromAccount ?: JSONObject.NULL); put("toAccount", m.toAccount ?: JSONObject.NULL)
            put("category", m.category); put("amount", m.amount); put("note", m.note)
            put("occurredAt", m.occurredAt); put("createdAt", m.createdAt); put("updatedAt", m.updatedAt)
            put("deletedAt", m.deletedAt ?: JSONObject.NULL)
        }) } }
        val categories = JSONArray().apply { snapshot.categories.forEach { c -> put(JSONObject().apply {
            put("id", c.id); put("name", c.name); put("type", c.type.name); put("archived", c.archived)
            put("createdAt", c.createdAt); put("updatedAt", c.updatedAt)
        }) } }
        val shares = JSONArray().apply { snapshot.shares.forEach { s -> put(JSONObject().apply {
            put("movementId", s.movementId); put("person", s.person); put("owedAmount", s.owedAmount)
            put("createdAt", s.createdAt); put("updatedAt", s.updatedAt)
        }) } }
        val payments = JSONArray().apply { snapshot.repayments.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("sharedMovementId", p.sharedMovementId); put("accountId", p.accountId)
            put("amount", p.amount); put("occurredAt", p.occurredAt); put("note", p.note)
            put("createdAt", p.createdAt); put("updatedAt", p.updatedAt); put("deletedAt", p.deletedAt ?: JSONObject.NULL)
        }) } }
        val content = JSONObject().put("accounts", accounts).put("movements", movements)
            .put("categories", categories).put("shares", shares).put("repayments", payments).toString()
        return JSONObject().put("format", FORMAT).put("backupVersion", BACKUP_VERSION)
            .put("exportedAt", System.currentTimeMillis()).put("checksumSha256", sha256(content)).put("data", content)
            .toString(2).toByteArray(StandardCharsets.UTF_8)
    }

    fun decode(bytes: ByteArray): Snapshot {
        require(bytes.size <= MAX_IMPORT_BYTES) { "Backup file exceeds 50 MB limit" }
        val root = JSONObject(String(bytes, StandardCharsets.UTF_8))
        require(root.getString("format") == FORMAT) { "Not a PocketLedger backup" }
        val version = root.getInt("backupVersion")
        require(version == 1 || version == 2) { "Unsupported backup version. Update PocketLedger Next." }
        val content = root.getString("data")
        val expected = root.getString("checksumSha256")
        require(MessageDigest.isEqual(expected.toByteArray(StandardCharsets.UTF_8), sha256(content).toByteArray(StandardCharsets.UTF_8))) {
            "Backup checksum mismatch; the file may be damaged"
        }
        val payload = JSONObject(content)
        val accountsJson = payload.getJSONArray("accounts")
        val movementsJson = payload.getJSONArray("movements")
        require(accountsJson.length() <= 5000 && movementsJson.length() <= 250000) { "Too many accounts or transactions" }
        val accounts = (0 until accountsJson.length()).map { i -> accountsJson.getJSONObject(i).let { o ->
            uuid(o.getString("id"))
            Account(o.getString("id"), o.getString("name"), AccountKind.valueOf(o.getString("kind")),
                o.getLong("openingBalance"), o.getLong("createdAt"), o.getLong("updatedAt"), o.longOrNull("deletedAt"))
        } }
        val movements = (0 until movementsJson.length()).map { i -> movementsJson.getJSONObject(i).let { o ->
            uuid(o.getString("id"))
            Movement(o.getString("id"), MovementType.valueOf(o.getString("type")), o.stringOrNull("fromAccount"),
                o.stringOrNull("toAccount"), o.getString("category"), o.getLong("amount"), o.getString("note"),
                o.getLong("occurredAt"), o.getLong("createdAt"), o.getLong("updatedAt"), o.longOrNull("deletedAt"))
        } }
        val categories: List<LedgerCategory>
        val shares: List<SharedExpense>
        val repayments: List<Repayment>
        if (version == 1) {
            // Keep every old transaction category, including custom strings from imported data.
            val now = System.currentTimeMillis()
            val names = expenseCategories.map { MovementType.EXPENSE to it } +
                incomeCategories.map { MovementType.INCOME to it } +
                movements.filter { it.type != MovementType.TRANSFER }.map { it.type to it.category }
            categories = names.distinctBy { "${it.first.name}:${it.second.lowercase()}" }.map { (type, name) ->
                LedgerCategory(UUID.randomUUID().toString(), name, type, false, now, now)
            }
            shares = emptyList()
            repayments = emptyList()
        } else {
            val cj = payload.getJSONArray("categories")
            val sj = payload.getJSONArray("shares")
            val pj = payload.getJSONArray("repayments")
            require(cj.length() <= 5000 && sj.length() <= 250000 && pj.length() <= 250000) { "Backup has too many category or shared records" }
            categories = (0 until cj.length()).map { i -> cj.getJSONObject(i).let { o ->
                uuid(o.getString("id"))
                LedgerCategory(o.getString("id"), o.getString("name"), MovementType.valueOf(o.getString("type")),
                    o.getBoolean("archived"), o.getLong("createdAt"), o.getLong("updatedAt"))
            } }
            shares = (0 until sj.length()).map { i -> sj.getJSONObject(i).let { o ->
                uuid(o.getString("movementId"))
                SharedExpense(o.getString("movementId"), o.getString("person"), o.getLong("owedAmount"),
                    o.getLong("createdAt"), o.getLong("updatedAt"))
            } }
            repayments = (0 until pj.length()).map { i -> pj.getJSONObject(i).let { o ->
                uuid(o.getString("id"))
                Repayment(o.getString("id"), o.getString("sharedMovementId"), o.getString("accountId"),
                    o.getLong("amount"), o.getLong("occurredAt"), o.getString("note"),
                    o.getLong("createdAt"), o.getLong("updatedAt"), o.longOrNull("deletedAt"))
            } }
        }
        return Snapshot(accounts, movements, categories, shares, repayments, root.getLong("exportedAt"))
    }

    fun saveBeforeRestore(context: Context, database: LedgerDatabase) {
        context.openFileOutput(PRE_RESTORE, Context.MODE_PRIVATE).use { out ->
            out.write(encode(capture(database))); out.fd.sync()
        }
    }
    fun hasPreRestore(context: Context): Boolean = context.getFileStreamPath(PRE_RESTORE).exists()
    fun loadPreRestore(context: Context): Snapshot = context.openFileInput(PRE_RESTORE).use { stream ->
        val bytes = stream.readBytes()
        require(bytes.size <= MAX_IMPORT_BYTES)
        decode(bytes)
    }

    private fun uuid(v: String) { UUID.fromString(v) }
    private fun JSONObject.stringOrNull(name: String): String? = if (isNull(name)) null else getString(name)
    private fun JSONObject.longOrNull(name: String): Long? = if (isNull(name)) null else getLong(name)
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(StandardCharsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
