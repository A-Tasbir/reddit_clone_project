package com.example.pocketledger

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

/** All changes are offline. Schema upgrades and backup imports never drop user data unexpectedly. */
class LedgerDatabase(context: Context) : SQLiteOpenHelper(context, "pocket_ledger.db", null, DATABASE_VERSION) {
    companion object { const val DATABASE_VERSION = 2 }

    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE accounts (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL,
                opening_balance INTEGER NOT NULL, created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL, deleted_at INTEGER
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE movements (
                id TEXT PRIMARY KEY, kind TEXT NOT NULL,
                from_account_id TEXT REFERENCES accounts(id),
                to_account_id TEXT REFERENCES accounts(id),
                category TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0),
                note TEXT NOT NULL, occurred_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
                deleted_at INTEGER
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX movements_by_date ON movements (occurred_at DESC)")
        val now = System.currentTimeMillis()
        for ((name, kind) in listOf(
            "Cash" to AccountKind.ASSET, "PayPay" to AccountKind.ASSET,
            "Bank" to AccountKind.ASSET, "Credit Card" to AccountKind.CREDIT
        )) {
            db.insertOrThrow("accounts", null, accountValues(Account(UUID.randomUUID().toString(), name, kind, 0L, now, now)))
        }
        createExtras(db)
        seedCategories(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion == 1 && newVersion >= 2) {
            createExtras(db)
            seedCategories(db)
            return
        }
        if (oldVersion != newVersion) throw IllegalStateException("Missing database migration from $oldVersion to $newVersion")
    }

    private fun createExtras(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE categories (
            id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE,
            kind TEXT NOT NULL, archived INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
            UNIQUE(kind, name)
        )""")
        db.execSQL("""CREATE TABLE shared_expenses (
            movement_id TEXT PRIMARY KEY REFERENCES movements(id) ON DELETE CASCADE,
            person TEXT NOT NULL, owed_amount INTEGER NOT NULL CHECK(owed_amount > 0),
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE repayments (
            id TEXT PRIMARY KEY,
            shared_movement_id TEXT NOT NULL REFERENCES shared_expenses(movement_id),
            account_id TEXT NOT NULL REFERENCES accounts(id),
            amount INTEGER NOT NULL CHECK(amount > 0), occurred_at INTEGER NOT NULL,
            note TEXT NOT NULL, created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL, deleted_at INTEGER
        )""")
        db.execSQL("CREATE INDEX repayments_by_expense ON repayments(shared_movement_id)")
        db.execSQL("CREATE INDEX repayments_by_date ON repayments(occurred_at DESC)")
    }

    private fun seedCategories(db: SQLiteDatabase) {
        val now = System.currentTimeMillis()
        val extra = mutableListOf<Pair<MovementType, String>>()
        db.rawQuery("SELECT DISTINCT kind, category FROM movements WHERE kind IN ('EXPENSE', 'INCOME')", null).use { c ->
            while (c.moveToNext()) extra.add(MovementType.valueOf(c.getString(0)) to c.getString(1))
        }
        val all = expenseCategories.map { MovementType.EXPENSE to it } + incomeCategories.map { MovementType.INCOME to it } + extra
        all.distinctBy { "${it.first.name}:${it.second.lowercase()}" }.forEach { (type, name) ->
            db.insertWithOnConflict("categories", null, categoryValues(LedgerCategory(UUID.randomUUID().toString(), name, type, false, now, now)), SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    fun accounts(): List<Account> = readableDatabase.query("accounts", null, null, null, null, null, "created_at, name").use { c ->
        buildList { while (c.moveToNext()) add(readAccount(c)) }
    }
    fun movements(includeDeleted: Boolean = false): List<Movement> = readableDatabase.query(
        "movements", null, if (includeDeleted) null else "deleted_at IS NULL", null, null, null, "occurred_at DESC, created_at DESC"
    ).use { c -> buildList { while (c.moveToNext()) add(readMovement(c)) } }
    fun categories(): List<LedgerCategory> = readableDatabase.query("categories", null, null, null, null, null, "kind, archived, name COLLATE NOCASE").use { c ->
        buildList { while (c.moveToNext()) add(readCategory(c)) }
    }
    fun shares(): List<SharedExpense> = readableDatabase.query("shared_expenses", null, null, null, null, null, "created_at DESC").use { c ->
        buildList { while (c.moveToNext()) add(readShare(c)) }
    }
    fun repayments(includeDeleted: Boolean = false): List<Repayment> = readableDatabase.query(
        "repayments", null, if (includeDeleted) null else "deleted_at IS NULL", null, null, null, "occurred_at DESC, created_at DESC"
    ).use { c -> buildList { while (c.moveToNext()) add(readRepayment(c)) } }

    fun saveAccount(account: Account) {
        require(account.name.isNotBlank() && account.name.length <= 60)
        val db = writableDatabase
        val previousKind = db.query("accounts", arrayOf("kind"), "id = ?", arrayOf(account.id), null, null, null).use { c -> if (c.moveToFirst()) c.getString(0) else null }
        if (previousKind != null && previousKind != account.kind.name) {
            val used = db.rawQuery("SELECT COUNT(*) FROM movements WHERE from_account_id = ? OR to_account_id = ?", arrayOf(account.id, account.id)).use { c -> c.moveToFirst(); c.getLong(0) > 0 }
            require(!used) { "Account type cannot change after a transaction" }
        }
        val values = accountValues(account)
        if (db.update("accounts", values, "id = ?", arrayOf(account.id)) == 0) db.insertOrThrow("accounts", null, values)
    }

    fun removeEmptyAccount(id: String): Boolean {
        val db = writableDatabase
        val used = db.rawQuery("SELECT (SELECT COUNT(*) FROM movements WHERE from_account_id = ? OR to_account_id = ?) + (SELECT COUNT(*) FROM repayments WHERE account_id = ?)", arrayOf(id, id, id)).use { c -> c.moveToFirst(); c.getLong(0) > 0 }
        if (used) return false
        return db.delete("accounts", "id = ?", arrayOf(id)) > 0
    }

    fun saveCategory(category: LedgerCategory) {
        require(category.type != MovementType.TRANSFER && category.name.isNotBlank() && category.name.length <= 60)
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = db.query("categories", null, "id = ?", arrayOf(category.id), null, null, null).use { c -> if (c.moveToFirst()) readCategory(c) else null }
            require(old == null || old.type == category.type) { "Category type cannot change" }
            val collision = db.rawQuery("SELECT COUNT(*) FROM categories WHERE kind=? AND name=? COLLATE NOCASE AND id!=?", arrayOf(category.type.name, category.name.trim(), category.id)).use { c -> c.moveToFirst(); c.getLong(0) }
            require(collision == 0L) { "This category name already exists" }
            val saved = category.copy(name = category.name.trim())
            val cv = categoryValues(saved)
            if (db.update("categories", cv, "id=?", arrayOf(saved.id)) == 0) db.insertOrThrow("categories", null, cv)
            if (old != null && old.name != saved.name) {
                db.update("movements", ContentValues().apply { put("category", saved.name) }, "kind=? AND category=? COLLATE NOCASE", arrayOf(saved.type.name, old.name))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeUnusedCategory(id: String): Boolean {
        val db = writableDatabase
        val old = db.query("categories", null, "id=?", arrayOf(id), null, null, null).use { c -> if (c.moveToFirst()) readCategory(c) else null } ?: return false
        val used = db.rawQuery("SELECT COUNT(*) FROM movements WHERE kind=? AND category=? COLLATE NOCASE", arrayOf(old.type.name, old.name)).use { c -> c.moveToFirst(); c.getLong(0) > 0L }
        if (used) return false
        return db.delete("categories", "id=?", arrayOf(id)) > 0
    }

    /** Save expense and its split atomically; repayments must never exceed the agreed share. */
    fun saveMovement(m: Movement, share: SharedExpense? = null) {
        validateMovement(m)
        require(share == null || (m.type == MovementType.EXPENSE && share.movementId == m.id && share.person.isNotBlank() && share.person.length <= 70 && share.owedAmount in 1..m.amount)) { "Invalid shared amount or person" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val existingShare = db.query("shared_expenses", arrayOf("movement_id"), "movement_id=?", arrayOf(m.id), null, null, null).use { it.moveToFirst() }
            val paid = db.rawQuery("SELECT COALESCE(SUM(amount), 0) FROM repayments WHERE shared_movement_id=? AND deleted_at IS NULL", arrayOf(m.id)).use { c -> c.moveToFirst(); c.getLong(0) }
            require(share != null || paid == 0L) { "Remove repayments before removing the shared split" }
            require(share == null || share.owedAmount >= paid) { "Shared share cannot be less than already repaid (${paid} yen)" }
            val cv = movementValues(m)
            if (db.update("movements", cv, "id=?", arrayOf(m.id)) == 0) db.insertOrThrow("movements", null, cv)
            if (share != null) {
                val values = shareValues(share)
                if (db.update("shared_expenses", values, "movement_id=?", arrayOf(share.movementId)) == 0) db.insertOrThrow("shared_expenses", null, values)
            } else if (existingShare) {
                // If there is repayment history (even soft-deleted), keep referential integrity.
                val hasAny = db.rawQuery("SELECT COUNT(*) FROM repayments WHERE shared_movement_id=?", arrayOf(m.id)).use { c -> c.moveToFirst(); c.getLong(0) > 0 }
                require(!hasAny) { "A split with repayment history cannot be removed" }
                db.delete("shared_expenses", "movement_id=?", arrayOf(m.id))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun deleteMovement(id: String) {
        val db = writableDatabase
        val hasRepayments = db.rawQuery("SELECT COUNT(*) FROM repayments WHERE shared_movement_id=?", arrayOf(id)).use { c -> c.moveToFirst(); c.getLong(0) > 0L }
        require(!hasRepayments) { "Remove linked repayment history before deleting this expense" }
        db.update("movements", ContentValues().apply {
            put("deleted_at", System.currentTimeMillis()); put("updated_at", System.currentTimeMillis())
        }, "id=?", arrayOf(id))
    }

    fun saveRepayment(payment: Repayment) {
        require(payment.amount in 1..1_000_000_000_000L && payment.note.length <= 300)
        val db = writableDatabase
        db.beginTransaction()
        try {
            val split = db.rawQuery("SELECT s.owed_amount, m.deleted_at FROM shared_expenses s JOIN movements m ON m.id=s.movement_id WHERE s.movement_id=?", arrayOf(payment.sharedMovementId)).use { c ->
                if (!c.moveToFirst()) null else Pair(c.getLong(0), !c.isNull(1))
            }
            require(split != null && !split.second) { "Shared expense no longer exists" }
            val account = db.rawQuery("SELECT COUNT(*) FROM accounts WHERE id=? AND deleted_at IS NULL", arrayOf(payment.accountId)).use { c -> c.moveToFirst(); c.getLong(0) }
            require(account > 0) { "Choose a valid account" }
            val paidOther = db.rawQuery("SELECT COALESCE(SUM(amount),0) FROM repayments WHERE shared_movement_id=? AND id!=? AND deleted_at IS NULL", arrayOf(payment.sharedMovementId, payment.id)).use { c -> c.moveToFirst(); c.getLong(0) }
            require(payment.amount <= split.first - paidOther) { "Payment exceeds the remaining amount owed" }
            val cv = repaymentValues(payment)
            if (db.update("repayments", cv, "id=?", arrayOf(payment.id)) == 0) db.insertOrThrow("repayments", null, cv)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun deleteRepayment(id: String) {
        writableDatabase.update("repayments", ContentValues().apply {
            put("deleted_at", System.currentTimeMillis()); put("updated_at", System.currentTimeMillis())
        }, "id=?", arrayOf(id))
    }

    /** All record groups import in one SQLite transaction. V1 imports carry empty shares and inferred categories. */
    fun restore(snapshot: BackupManager.Snapshot) {
        val (acc, mov, cats, shares, pay) = snapshot
        require(acc.isNotEmpty() || (mov.isEmpty() && pay.isEmpty()))
        require(acc.map { it.id }.distinct().size == acc.size && mov.map { it.id }.distinct().size == mov.size)
        require(cats.map { it.id }.distinct().size == cats.size && shares.map { it.movementId }.distinct().size == shares.size && pay.map { it.id }.distinct().size == pay.size)
        val ids = acc.map { it.id }.toSet()
        val byId = mov.associateBy { it.id }
        val shareById = shares.associateBy { it.movementId }
        for (a in acc) require(a.id.isNotBlank() && a.name.isNotBlank())
        for (m in mov) {
            validateMovement(m)
            require(m.fromAccount == null || m.fromAccount in ids)
            require(m.toAccount == null || m.toAccount in ids)
        }
        for (c in cats) require(c.name.isNotBlank() && c.name.length <= 60 && c.type != MovementType.TRANSFER)
        require(cats.map { "${it.type.name}:${it.name.lowercase()}" }.distinct().size == cats.size) { "Duplicate category names" }
        for (s in shares) {
            val m = byId[s.movementId]
            require(m != null && m.type == MovementType.EXPENSE && s.owedAmount in 1..m.amount && s.person.isNotBlank())
        }
        for (p in pay) require(p.sharedMovementId in shareById && p.accountId in ids && p.amount > 0 && p.note.length <= 300)
        for (s in shares) require(pay.filter { it.sharedMovementId == s.movementId && it.deletedAt == null }.sumOf { it.amount } <= s.owedAmount)
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("repayments", null, null)
            db.delete("shared_expenses", null, null)
            db.delete("movements", null, null)
            db.delete("categories", null, null)
            db.delete("accounts", null, null)
            acc.forEach { db.insertOrThrow("accounts", null, accountValues(it)) }
            cats.forEach { db.insertOrThrow("categories", null, categoryValues(it)) }
            mov.forEach { db.insertOrThrow("movements", null, movementValues(it)) }
            shares.forEach { db.insertOrThrow("shared_expenses", null, shareValues(it)) }
            pay.forEach { db.insertOrThrow("repayments", null, repaymentValues(it)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun validateMovement(m: Movement) {
        require(m.amount in 1..1_000_000_000_000L && m.category.length <= 80 && m.note.length <= 300) { "Invalid transaction amount or text" }
        when (m.type) {
            MovementType.EXPENSE -> require(m.fromAccount != null && m.toAccount == null)
            MovementType.INCOME -> require(m.toAccount != null && m.fromAccount == null)
            MovementType.TRANSFER -> require(m.fromAccount != null && m.toAccount != null && m.fromAccount != m.toAccount)
        }
    }

    private fun accountValues(a: Account) = ContentValues().apply {
        put("id", a.id); put("name", a.name); put("kind", a.kind.name)
        put("opening_balance", a.openingBalance); put("created_at", a.createdAt); put("updated_at", a.updatedAt)
        if (a.deletedAt == null) putNull("deleted_at") else put("deleted_at", a.deletedAt)
    }
    private fun movementValues(m: Movement) = ContentValues().apply {
        put("id", m.id); put("kind", m.type.name)
        if (m.fromAccount == null) putNull("from_account_id") else put("from_account_id", m.fromAccount)
        if (m.toAccount == null) putNull("to_account_id") else put("to_account_id", m.toAccount)
        put("category", m.category); put("amount", m.amount); put("note", m.note)
        put("occurred_at", m.occurredAt); put("created_at", m.createdAt); put("updated_at", m.updatedAt)
        if (m.deletedAt == null) putNull("deleted_at") else put("deleted_at", m.deletedAt)
    }
    private fun categoryValues(c: LedgerCategory) = ContentValues().apply {
        put("id", c.id); put("name", c.name); put("kind", c.type.name); put("archived", if (c.archived) 1 else 0)
        put("created_at", c.createdAt); put("updated_at", c.updatedAt)
    }
    private fun shareValues(s: SharedExpense) = ContentValues().apply {
        put("movement_id", s.movementId); put("person", s.person); put("owed_amount", s.owedAmount)
        put("created_at", s.createdAt); put("updated_at", s.updatedAt)
    }
    private fun repaymentValues(p: Repayment) = ContentValues().apply {
        put("id", p.id); put("shared_movement_id", p.sharedMovementId); put("account_id", p.accountId)
        put("amount", p.amount); put("occurred_at", p.occurredAt); put("note", p.note)
        put("created_at", p.createdAt); put("updated_at", p.updatedAt)
        if (p.deletedAt == null) putNull("deleted_at") else put("deleted_at", p.deletedAt)
    }
    private fun Cursor.str(key: String): String = getString(getColumnIndexOrThrow(key))
    private fun Cursor.num(key: String): Long = getLong(getColumnIndexOrThrow(key))
    private fun Cursor.strOrNull(key: String): String? = getColumnIndexOrThrow(key).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.longOrNull(key: String): Long? = getColumnIndexOrThrow(key).let { if (isNull(it)) null else getLong(it) }
    private fun readAccount(c: Cursor) = Account(c.str("id"), c.str("name"), AccountKind.valueOf(c.str("kind")), c.num("opening_balance"), c.num("created_at"), c.num("updated_at"), c.longOrNull("deleted_at"))
    private fun readMovement(c: Cursor) = Movement(c.str("id"), MovementType.valueOf(c.str("kind")), c.strOrNull("from_account_id"), c.strOrNull("to_account_id"), c.str("category"), c.num("amount"), c.str("note"), c.num("occurred_at"), c.num("created_at"), c.num("updated_at"), c.longOrNull("deleted_at"))
    private fun readCategory(c: Cursor) = LedgerCategory(c.str("id"), c.str("name"), MovementType.valueOf(c.str("kind")), c.num("archived") != 0L, c.num("created_at"), c.num("updated_at"))
    private fun readShare(c: Cursor) = SharedExpense(c.str("movement_id"), c.str("person"), c.num("owed_amount"), c.num("created_at"), c.num("updated_at"))
    private fun readRepayment(c: Cursor) = Repayment(c.str("id"), c.str("shared_movement_id"), c.str("account_id"), c.num("amount"), c.num("occurred_at"), c.str("note"), c.num("created_at"), c.num("updated_at"), c.longOrNull("deleted_at"))
}
