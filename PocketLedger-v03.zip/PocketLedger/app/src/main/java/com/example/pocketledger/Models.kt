package com.example.pocketledger

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AccountKind { ASSET, CREDIT }
enum class MovementType { EXPENSE, INCOME, TRANSFER }

data class Account(
    val id: String,
    val name: String,
    val kind: AccountKind,
    val openingBalance: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

data class Movement(
    val id: String,
    val type: MovementType,
    val fromAccount: String?,
    val toAccount: String?,
    val category: String,
    val amount: Long,
    val note: String,
    val occurredAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

data class LedgerCategory(
    val id: String,
    val name: String,
    val type: MovementType,
    val archived: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)

/** One optional split per expense; the other person's agreed share need not be exactly half. */
data class SharedExpense(
    val movementId: String,
    val person: String,
    val owedAmount: Long,
    val createdAt: Long,
    val updatedAt: Long
)

/** Cash actually received later; tracked separately to avoid inflating normal income. */
data class Repayment(
    val id: String,
    val sharedMovementId: String,
    val accountId: String,
    val amount: Long,
    val occurredAt: Long,
    val note: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

val expenseCategories = listOf("Food", "Groceries", "Rent", "Transport", "Utilities", "Shopping", "Health", "Education", "Entertainment", "Other")
val incomeCategories = listOf("Salary", "Part-time work", "Gift", "Refund", "Other")

fun yen(value: Long): String = "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(value)
fun dateText(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date(timestamp))
fun monthBounds(now: Long = System.currentTimeMillis()): Pair<Long, Long> {
    val cal = java.util.Calendar.getInstance().apply {
        timeInMillis = now
        set(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }
    val start = cal.timeInMillis
    cal.add(java.util.Calendar.MONTH, 1)
    return start to cal.timeInMillis
}

fun paymentsFor(id: String, repayments: List<Repayment>): Long =
    repayments.filter { it.sharedMovementId == id && it.deletedAt == null }.sumOf { it.amount }

fun outstanding(shared: SharedExpense, repayments: List<Repayment>): Long =
    (shared.owedAmount - paymentsFor(shared.movementId, repayments)).coerceAtLeast(0L)

fun accountBalances(accounts: List<Account>, movements: List<Movement>, repayments: List<Repayment> = emptyList()): Map<String, Long> {
    val result = accounts.associate { it.id to it.openingBalance }.toMutableMap()
    for (m in movements) {
        if (m.deletedAt != null) continue
        if (m.type != MovementType.INCOME) {
            val from = m.fromAccount ?: continue
            result[from] = (result[from] ?: 0L) - m.amount
        }
        if (m.type != MovementType.EXPENSE) {
            val to = m.toAccount ?: continue
            result[to] = (result[to] ?: 0L) + m.amount
        }
    }
    for (r in repayments) {
        if (r.deletedAt != null) continue
        result[r.accountId] = (result[r.accountId] ?: 0L) + r.amount
    }
    return result
}
